from django.contrib import admin

from app.models import Students

# Register your models here.
admin.site.register(Students)