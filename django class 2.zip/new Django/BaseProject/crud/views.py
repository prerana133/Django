from django.shortcuts import render
from flask import redirect
from crud.models import Students

# Create your views here.
def readAll(request):

    if request.method == "POST":
        name = request.POST.get("name")
        age = request.POST.get("age")
        course = request.POST.get("course")

        Students.objects.create(name=name,age=age,course=course)

    

    context = {
        'students' : Students.objects.all()
    }

    return render(request,'readAll.html',context)

