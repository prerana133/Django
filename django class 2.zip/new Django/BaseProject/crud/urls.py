from django.urls import path
from crud import views

urlpatterns = [
    path('readAll',views.readAll,name="readAll"),
]
