import { Injectable } from '@angular/core';
import { Todo } from '../models/todo.type';

@Injectable({
  providedIn: 'root'
})
export class TodoService {

  todoItems: Array<Todo> = [
    {id:1,title:"Python",completed:true},
    {id:2,title:"Java",completed:false},
    {id:3,title:"Javascript",completed:true},
    {id:4,title:"Typesctipt",completed:true},
  ]

  addTodo(todo: Todo){
      this.todoItems.push(todo);
  }

  constructor() { }
}
