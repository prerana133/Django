import { Component, inject, OnInit, signal } from '@angular/core';
import { Todo } from '../../models/todo.type';
import { TodoService } from '../../services/todo.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-todo',
  imports: [FormsModule],
  templateUrl: './todo.component.html',
  styleUrl: './todo.component.css'
})

export class TodoComponent implements OnInit {
    name = "prerana";
    name2 = signal("prerana");

    changeName(){
       if(this.name === "prerana"){
          this.name = "anvesh";
       } else if (this.name === "anvesh"){
          this.name = "prerana";
       }
    }


    changeNameUsingSignal(){
        // console.log(this.name2());
        if(this.name2() === "prerana"){
            this.name2.set("anvesh");
        } else if(this.name2() === "anvesh"){
            // set when setting it for first time or chanage it completly 
            this.name2.set("prerana");
        }
    }



    todoItems = signal<Array<Todo>>([]);
    todoService = inject(TodoService);

    ngOnInit(): void {
      // console.log("First render");
      this.todoItems.set(this.todoService.todoItems);
      // console.log(this.todoItems());
    }


    title = signal("");

    addFormSubmit(){
      console.log(this.title());
      // todo = {id:1,title: this.title(),completed: false}; 
    }

}
