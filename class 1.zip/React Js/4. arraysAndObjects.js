// let ages = [10,20,30,40];

// console.log(ages.length)
// // console.log(ages.)
// ages.push(50)
// console.log(ages)


// // like python range
// for(let i=0; i<ages.length ; i++){
//     console.log(i,ages[i]);
// }

// // for i in ages:
// for(let i of ages){
//     console.log(i);
// }







// objects(json) means dictionary in python
let details = {
    id: 1,
    name: "Anvesh",
    age:  22,
    present: true
}

console.log(details);

console.log(details["id"]);
console.log(details.id);

console.log(details["name"]);
console.log(details.name);






let students = [
    {
        id: 1,
        name: "Anvesh",
        age:  22,
        present: true
    },
    {
        id: 2,
        name: "Surya",
        age:  23,
        present: false
    },
    {
        id: 3,
        name: "Prerana",
        age:  23,
        present: false
    },
    {
        id: 4,
        name: "satish",
        age:  22,
        present: true
    }
]

console.log(students);


for(let i of students){
    console.log(i.id);
    console.log(i.name);
    console.log(i.age);
    console.log(i.present); 
    console.log()
}

