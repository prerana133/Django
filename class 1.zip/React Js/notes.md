
---

# 📘 JavaScript & Node.js Notes

## 🔗 Node.js
- Website: [https://nodejs.org/en](https://nodejs.org/en)
- Used to run JavaScript outside the browser (server-side JavaScript).

### ✅ Check Installation
```bash
node --version    # Check Node.js version
npm --version     # Check npm (Node Package Manager) version
```

> **npm** is similar to **pip** in Python — used to install and manage packages.

### ▶️ Run JavaScript File
```bash
node filename.js
```

---

## 🧠 JavaScript Function Types

### 1. **Normal Function**
- Uses the `function` keyword.

```javascript
function greet() {
  console.log("Hello!");
}
```

### 2. **Anonymous Function**
- Function without a name, assigned to a variable.

```javascript
const greet = function() {
  console.log("Hello!");
};
```

### 3. **Arrow Function**
- Shorter syntax, introduced in ES6.

```javascript
const greet = () => {
  console.log("Hello!");
};
```

---

## 🌟 Spread Operator (`...`) & Rest Parameters

- Similar to `*args` in Python.
- **Spread Operator**: Expands an array/object.
  
```javascript
const nums = [1, 2, 3];
const newNums = [...nums, 4, 5];
console.log(newNums); // [1, 2, 3, 4, 5]
```

- **Rest Parameter**: Collects multiple arguments into an array.

```javascript
function sum(...numbers) {
  return numbers.reduce((a, b) => a + b, 0);
}

console.log(sum(1, 2, 3, 4)); // 10
```

---

