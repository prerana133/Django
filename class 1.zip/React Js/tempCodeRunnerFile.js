
let a = [1,2,3,4,5]
let b = [6,7,8,9,10]

let res = [a,b];
console.log(res);

let res2 = [...a,...b];
console.log(res2)

for(let i of res){
    console.log(i);
}