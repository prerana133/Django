let ages = [10,20,30,40,50]

console.log(ages);

console.log(10,20,30,40,50);
console.log(...ages);


// rest parameter
// def add(*numbers):
//     print(numbers)

function add(...numbers){
    // console.log(numbers);
    let sum = 0;
    
    // for(let i of numbers){
    //     sum+= i
    // }

    for(let i=0 ; i<numbers.length ;i++){
        sum += numbers[i]
    }

    return sum;
}

add();
add(10,20,30);
add(10,20,30,40,50);
console.log(add(10,20,30));
console.log(add(10));
console.log(add(10,20,30,40,50));





let a = [1,2,3,4,5]
let b = [6,7,8,9,10]

let res = [a,b];
console.log(res);

let res2 = [...a,...b];
console.log(res2)

for(let i of res){
    console.log(i);
}

for(let i of res2){
    console.log(i);
}