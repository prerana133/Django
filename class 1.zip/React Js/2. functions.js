// function addNormalFunction(a,b){
//     return a+b;
// }

// addNormalFunction(10,20) // not show output
// console.log(addNormalFunction(10,20));  // this will show 30 

// let res = addNormalFunction(20,30);
// console.log(res); // this will show 50 




// let addAnnonomus = function(a,b){
//     return a+b;
// }

// console.log(addAnnonomus(20,30))
// let res2 = addAnnonomus(30,40);
// console.log(res2);



let addAF = (a,b) => {
    return a+b;
}

console.log(addAF(10,30))


let hello = () =>{
    console.log("Hello World!");
}

hello()