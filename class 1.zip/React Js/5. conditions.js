
let age = 20;

if(age>18){
    console.log("valid age");
}else{
    console.log("under age")
}


// condition ? true : false;
// turnary operator
age>18 ? console.log("valid age") : console.log("under age");


// and operator
age>18 && console.log("valid age");

!(age>18) && console.log("under age");
